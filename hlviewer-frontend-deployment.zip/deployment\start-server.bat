@echo off
REM Запуск React приложения на Windows Server
REM
REM Требования:
REM - Node.js установлен на сервере
REM - Файлы приложения скопированы в эту папку

echo ===============================================
echo    Запуск React Frontend приложения
echo ===============================================
echo.

REM Проверяем наличие Node.js
where node >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo ❌ ОШИБКА: Node.js не найден в системе
    echo    Пожалуйста, установите Node.js или добавьте его в PATH
    echo.
    pause
    exit /b 1
)

REM Показываем версию Node.js
echo ✅ Node.js найден:
node --version
echo.

REM Проверяем наличие файлов приложения
if not exist "dist\index.html" (
    echo ❌ ОШИБКА: Файлы приложения не найдены
    echo    Убедитесь, что папка 'dist' с файлами приложения находится в текущей директории
    echo.
    pause
    exit /b 1
)

echo ✅ Файлы приложения найдены
echo.

REM Запускаем сервер
echo 🚀 Запуск сервера...
echo    Приложение будет доступно по адресу: http://localhost:3000
echo    Для остановки нажмите Ctrl+C
echo.

node simple-server.js

echo.
echo ⏹️  Сервер остановлен
pause