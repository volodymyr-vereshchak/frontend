/**
 * Простой HTTP сервер для обслуживания React приложения
 * Для использования на Windows Server без интернета
 *
 * Использование:
 * node simple-server.js
 *
 * Приложение будет доступно по адресу http://localhost:3000
 */

const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const DIST_DIR = path.join(__dirname, 'dist');

// MIME types
const mimeTypes = {
  '.html': 'text/html',
  '.js': 'application/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2'
};

function getContentType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  return mimeTypes[ext] || 'application/octet-stream';
}

function serveFile(res, filePath) {
  fs.readFile(filePath, (err, data) => {
    if (err) {
      console.error(`Error reading file ${filePath}:`, err);
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      res.end('Internal Server Error');
      return;
    }

    const contentType = getContentType(filePath);
    res.writeHead(200, {
      'Content-Type': contentType,
      'Cache-Control': 'no-cache, no-store, must-revalidate',
      'Pragma': 'no-cache',
      'Expires': '0'
    });
    res.end(data);
  });
}

const server = http.createServer((req, res) => {
  let requestPath = req.url;

  // Remove query parameters
  const queryIndex = requestPath.indexOf('?');
  if (queryIndex !== -1) {
    requestPath = requestPath.substring(0, queryIndex);
  }

  // Security: prevent directory traversal
  if (requestPath.includes('..')) {
    res.writeHead(400, { 'Content-Type': 'text/plain' });
    res.end('Bad Request');
    return;
  }

  // API proxy (если нужно)
  if (requestPath.startsWith('/api/')) {
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('API endpoint not configured. Please set up reverse proxy to your backend.');
    return;
  }

  // Determine file path
  let filePath;
  if (requestPath === '/' || requestPath === '/index.html') {
    filePath = path.join(DIST_DIR, 'index.html');
  } else {
    filePath = path.join(DIST_DIR, requestPath);
  }

  // Check if file exists
  fs.access(filePath, fs.constants.F_OK, (err) => {
    if (err) {
      // File doesn't exist, serve index.html for SPA routing
      console.log(`File not found: ${filePath}, serving index.html for SPA routing`);
      filePath = path.join(DIST_DIR, 'index.html');
    }

    serveFile(res, filePath);
  });
});

server.listen(PORT, () => {
  console.log(`🚀 React приложение запущено на http://localhost:${PORT}`);
  console.log(`📁 Обслуживает файлы из: ${DIST_DIR}`);
  console.log('');
  console.log('Для остановки сервера нажмите Ctrl+C');
  console.log('');
  console.log('⚠️  Убедитесь, что backend API доступен для корректной работы приложения');
});

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n🛑 Получен сигнал остановки, завершение работы сервера...');
  server.close(() => {
    console.log('✅ Сервер остановлен');
    process.exit(0);
  });
});

// Error handling
server.on('error', (err) => {
  console.error('❌ Ошибка сервера:', err);
  process.exit(1);
});